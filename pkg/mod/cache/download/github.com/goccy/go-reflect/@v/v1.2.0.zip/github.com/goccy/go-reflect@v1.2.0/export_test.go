package reflect

type Buffer struct {
	buf []byte
}
